def add(x, y):
    print("Sum is ", x+y )