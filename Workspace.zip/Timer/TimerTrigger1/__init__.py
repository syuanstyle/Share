import datetime
import logging
import json
import requests

import azure.functions as func

valueA=1
valueB=2

def main(mytimer: func.TimerRequest) -> None:
    utc_timestamp = datetime.datetime.utcnow().replace(
        tzinfo=datetime.timezone.utc).isoformat()

    print("Test ***************")
    print("testFuncA(): ", testFuncA())
    ct = datetime.datetime.now()
    print("current time:-", ct, ", type: ", type(ct))
    ts = ct.timestamp()
    print("timestamp:-", ts, ", type: ", type(ts))
    logging.info('Python timer trigger function ran at %s', utc_timestamp)

def testFuncA():
    sum = valueA+valueB
    print("Sum is ", sum )
    r = requests.get('https://www.google.com.tw/')
    print(r.status_code)
    return sum